cd ~/Bureau/
sudo rm -rf /media/bonjour/DF11CLONE/home/partimag/DF11-img/
sudo rsync -av --progress DF11-img /media/bonjour/DF11CLONE/home/partimag/