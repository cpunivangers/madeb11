# Modification firefox-esr

## Addons (via apt)
- webext-https-everywhere
- webext-ublock-origin

#Bookmarkbar
Debian-facile => https://debian-facile.org/forum.php
L'agenda du libe => https://www.agendadulibre.org/pages/filter

# UI
Personnaliser > [PREC SUIV REFRESH URLBAR DDL UBLOCK PREF] + activé la barre personnelle
about:home > tout décoché sauf "Recherche"
about:pref#search > ajout des moteurs de rechercher lilo, ecosia, framabee; retiré Bing, Amazone, Ebay; mis DuckDuck par défaut
about:pref#general#privacy > NULL


## about:config
- network.IDN_show_punycode = true (Not rendering IDNs as their Punycode equivalent leaves you open to phishing attacks that can be very difficult to notice.)
- network.allow-experiments = false
- browser.backspace_action = 1 (Pour éviter que la touche d'effacement Retour arrière déclenche un retour à la page précédente)
- browser.safebrowsing.malware.enabled = false (Disable Google Safe Browsing malware checks. Security risk, but privacy improvement.)
- browser.safebrowsing.phishing.enabled = false (Disable Google Safe Browsing malware checks. Security risk, but privacy improvement.)
- browser.safebrowsing.downloads.remote.enabled = false (autorise le téléchargement de la liste Google qui gère la reconnaissance des malwares)
- browser.send_pings.require_same_host = true (autorise le suivi seulement s'il y a correspondance entre l'hôte qui envoi et qui reçoit)
- browser.urlbar.speculativeConnect.enabled = false (Disable preloading of autocomplete URLs)
- browser.newtabpage.activity-stream.feeds.telemetry = false
- browser.newtabpage.activity-stream.telemetry = false
- browser.ping-centre.telemetry = false
- extensions.pocket.enabled = false (Disables Pocket completely.)
- extensions.blocklist.url = https://blocklists.settings.services.mozilla.com/v1/blocklist/3/%20/%20/ (Limit the amount of identifiable information sent when requesting the Mozilla harmful extension blocklist. )
- privacy.resistFingerprinting = true (makes Firefox more resistant to browser fingerprinting.)
- privacy.trackingprotection.enabled = false (doublon avec Ublock origin)
- dom.battery.enabled = false (The battery status of your device could be tracked.)
- dom.event.contextmenu.enabled = false (empêche le javascript d'interdir le menu contextuel)
- geo.enabled = false (Disables geolocation.)
- media.gmp-widevinecdm.enabled = false (Disables the Widevine Content Decryption Module provided by Google Inc)
- media.navigator.enabled = false (Websites can track the microphone and camera status of your device.)
- permissions.default.geo = 2 (paramétrez une permission par défaut pour la géolocalisation : 2= bloquer)
- toolkit.telemetry.unified = false
- toolkit.telemetry.cachedClientID = ''
- toolkit.telemetry.archive.enabled = false
- toolkit.telemetry.bhrPing.enabled = false
- toolkit.telemetry.server = ''
- experiments.activeExperiment = false
- experiments.enabled = false
- experiments.supported = false


### This change was already the default

#- network.prefetch-next = false (Désactiver le téléchargement en avance des pages web)
#- network.dns.disablePrefetch = true (Désactiver la résolution DNS en avance)
#- network.predictor.enabled = false
#- browser.send_pings = false (The attribute would be useful for letting websites track visitors' clicks.)
#- media.eme.enabled = false (Disables playback of DRM-controlled HTML5 content)
#- datareporting.healthreport.uploadEnabled = false (Je ne souhaite pas que Firefox envoie des informations sur mon utilisation)
#- toolkit.telemetry.enabled = false 


### Advised but choosed not to enable

#network.cookie.cookieBehavior = 1
#network.cookie.lifetimePolicy = 1
#network.http.referer.trimmingPolicy = 2
#network.http.referer.XOriginPolicy = 2
#network.http.referer.XOriginTrimmingPolicy = 2
#browser.sessionstore.privacy_level = 2
#browser.safebrowsing.downloads.enabled = false
#dom.event.clipboardevents.enabled = false (Disable that websites can get notifications if you copy, paste, or cut)
#privacy.firstparty.isolate = true
#webgl.disabled = true









#SOURCE
https://www.privacytools.io/browsers/#about_config
https://blog.stephane-huc.net/securite/systeme/firefox-ameliorer-sa-securite